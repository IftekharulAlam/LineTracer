-------- PROJECT GENERATOR --------
PROJECT NAME :	LineTracer
PROJECT DIRECTORY :	C:\WorkSpace\LineTracer\LineTracer
CPU SERIES :	R8C/Tiny
CPU GROUP :	34C
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	6.00.00
GENERATION FILES :
    C:\WorkSpace\LineTracer\LineTracer\LineTracer.cpp
        main program file.
    C:\WorkSpace\LineTracer\LineTracer\nc_define.inc
        interrupt program.
START UP FILES :
    C:\WorkSpace\LineTracer\LineTracer\ncrt0.a30
    C:\WorkSpace\LineTracer\LineTracer\sect30.inc
    C:\WorkSpace\LineTracer\LineTracer\sfr_r834c.inc
    C:\WorkSpace\LineTracer\LineTracer\sfr_r834c.h

DATE & TIME : 10/22/2021 2:03:56 AM
