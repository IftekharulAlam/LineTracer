#include "sfr_r834c.h" 
#include "Prototype.h" 
enum { STOP,FORWARD,BACKWARD,TORIGHT,TOLEFT };
extern unsigned short ad_data[4]; //A/D conversion result 
enum {
 TM00, //SCI timer
 TM01, //
 TMRNUM
}; 
enum {
 START_PB,
 INNUM
};
enum { OFF,ON,UP };
enum { NEG, POS }; 