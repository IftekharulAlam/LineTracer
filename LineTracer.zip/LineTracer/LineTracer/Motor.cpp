#include "LineTracer.h"
#define PERIOD 40000
static long maxValue;
void InitMotor(int rate)
{
    maxValue = ((long)PERIOD * rate) / 100;
    trdgra0 = trdgrc0 = PERIOD - 1;
    trdgrb0 = trdgrd0 = maxValue / 2; // PWM 1
    trdgra1 = trdgrc1 = maxValue / 2; // PWM 2
    trdstr = 0x05;                    // start TRD0 count
}

void MotorDrive(int dir, int left, int right)
{
    if (dir == STOP) //Stop
    {
        p2_1 = 0;
        p2_6 = 0;
        p2_3 = 0;
        p2_7 = 0;
    }
    else
    {
        trdgrd0 = (maxValue * left) / 100;  // PWM1
        trdgrc1 = (maxValue * right) / 100; // PWM2
        switch (dir)
        {
        case FORWARD:
            p2_1 = 0; // Left wheel
            p2_6 = 1;
            p2_3 = 0; // Right wheel
            p2_7 = 1;
            break;
        case BACKWARD:
            p2_1 = 1; // Left wheel
            p2_6 = 0;
            p2_3 = 1; // Right wheel
            p2_7 = 0;
            break;
        case TORIGHT:
            p2_1 = 0; // Left Forward
            p2_6 = 1;
            p2_3 = 1; // Right Backward
            p2_7 = 0;
            break;
        case TOLEFT:
            p2_1 = 1; // Left Backward
            p2_6 = 0;
            p2_3 = 0; // Right Forward
            p2_7 = 1;
            break;
        }
    }
}
void wheel(int lm, int rm)
{
    if (lm == 0)
    {
        p2_1 = 0;
        p2_6 = 0;
    }
    if (lm > 0)
    {
        p2_1 = 0; // Left wheel
        p2_6 = 1;
    }
    else if (lm < 0)
    {
        p2_1 = 1; // Left wheel
        p2_6 = 0;
    }

    if (rm == 0)
    {
        p2_3 = 0;
        p2_7 = 0;
    }
    if (rm > 0)
    {
        p2_3 = 0; // Right wheel
        p2_7 = 1;
    }
    else if (rm < 0)
    {
        p2_3 = 1; // Right wheel
        p2_7 = 0;
    }
    if (lm > 100)
        lm = 100;
    if (lm < -100)
        lm = -100;
    if (rm > 100)
        rm = 100;
    if (rm < -100)
        rm = -100;
    trdgrd0 = (maxValue * lm) / 100; // PWM1
    trdgrc1 = (maxValue * rm) / 100; // PWM2
}