#include "LineTracer.h"
static void mcu_init(void);
static void port_init(void);
static void timer_rd_init(void);
static void uart_init(void);
static void ad_init(void);
static void timer_ra_init();

void Hwsetup(void)
{
    asm("FCLR I"); /* Interrupt disabled */
    mcu_init();
    port_init();
    timer_ra_init();
    timer_rd_init();
    uart_init();
    ad_init();

    asm("FSET I"); /* Interrupt enable */
}

static void timer_ra_init()
{
    tstart_tracr = 0; /* Stop Timer RA operation */
    while (tcstf_tracr != 0)
        ;
    /* wait until tcstf_tracr becomes 0*/
    traic = 0x00; /* Disable Timer RA Interrupt */
    tstop_tracr = 1;
    /* The TRAPRE and TRA registers are initialized */
    /* Period between underflows 10ms */
    trapre = 128 - 1;
    /* Set (128 - 1) in TRAPRE register */
    tra = 195 - 1; /* Set (195 - 1) in TRA register */
    trasr = 0x00;  /* TRAIO pin not used */
    traioc = 0x00; /* Set to "0" in timer mode */
    tramr = 0x10;  /* Set to "000" in timer mode */
    /* Select "f8" in Count Source */
    /* Provides count source */
    traic = 0x05;     //enable Timer RA Interrupt level 5
    tstart_tracr = 1; /* Start Timer RA operation */
    while (tcstf_tracr != 1)
        ;
    /* wait until tcstf_tracr becomes 1 */
}
static void uart_init()
{
    pd1_5 = 0;   /* Pd1_5/RXD0 = input */
    u0sr = 0x05; /* TXD0 pin:P1_4 */
    /* RXD0 pin:P1_5 */
    /* CLK0 pin:not used */
    s0tic = 0x04;
    /* UART0 transmit interrupt level 4 */
    s0ric = 0x06; /* UART0 receive interrupt level 6 */
    te_u0c1 = 0;  /* Transmit enable:disabled */
    re_u0c1 = 0;  /* Receive enable:disabled */
    u0mr = 0x65;  /* Serial I/O mode:UART mode, */
    /*transfer data 8 bits long */
    /* Internal/external clock: Internal clock */
    /* Stop bit length: One stop bit */
    /* Odd/even parity: Even */
    /* Parity enable: Parity enabled */
    u0c0 = 0x00; /* BRG count source: f1 */
    /* Data output: TXD0 pin set to CMOS output */
    /* Transfer format: LSB first */
    u0c1 = 0x00; /* Transmit enable: disabled */
    /* Receive enable: disabled */
    /* UART0 transmit interrupt source:*/
    /*Transmission completed (TI= 1) */
    /* UART0 continuous receive mode:*/
    /*Continuous receive mode disabled */
    u0brg = 130 - 1;
    /* 20MHz * 1/1 * 1/(129+1) * 1/16 = 9615bps */
    // te_u0c1 = 1; /* Transmit enable:enabled */
    // re_u0c1 = 1;
}
static void timer_rd_init()
{
    trdpsr0 = 0x08; // TRDIOB0 = P2_2
    trdpsr1 = 0x01; // TRDIOA1 = P2_4
    trdmr = 0x70;   // Buffer register
    trdfcr = 0x01;  //Reset Synchronous Mode
    trdcr0 = 0x23;  //TRD0 cleared at compare match
    trdoer1 = 0xED; //Enable TRDIOB0,TRDIOA1
}

static void mcu_init()
{
    //Set High-speed on-chip oscillator clock to System clock
    prc0 = 1; /* Protect off */ /*CM0,CM1,CM3,*/
    /* OCD,FRA0,FRA1,FRA2,FRA3*/
    cm14 = 0;    /* Low-speed on-chip oscillator on */
    fra2 = 0x00; /* Selects Divide-by-2 mode */
    fra00 = 1;   /* High-speed on-chip oscillator on */
    for (int n = 0; n <= 2040; n++)
        ;
    // This setting is an example of waiting time for the
    // oscillation stabilization. Please evaluate the time
    // for oscillation stabilization by a user.
    fra01 = 1; // Selects High-speed on-chip oscillator
    ocd2 = 1;
    //System clock : On-chip oscillator clock selected
    cm1 &= 0x3F;
    //No division mode in system clock division
    cm06 = 0;     /* CM16 and CM17 enable */
    cm14 = 1;     /* Low-speed on-chip oscillator off */
    prc0 = 0;     /* Protect on */
    trbmr = 0x80; /*Timer RB count source cutoff*/
    mstcr = 0x28; /* SSU, I2C and Timer RC*/
                  /*to Standby mode*/
}

static void port_init()
{
    //P0_5 LEDA
    //P0_6 LEDB
    //P0_7 LEDC
    // Setting port registers */
    p0 = 0; /* LED port off */
    // Setting port direction registers */
    prc2 = 1;    /* Protect off */
    pd0 |= 0xE0; /* LED port direction = output */
    // SWITCH Button & Motor Output
    p2 = 0; //P2_0=Switch Input,
    //P2_1...P2_7=Motor Output
    pu04 = 1;   //Pullup for Switch Input
    pd2 = 0xFE; //P2_0 Input, P2_1...P2_7 Output
}
static void ad_init()
{
    unsigned char work; //Variable for PD0 register
    /* ==== Read PD0 register ==== */
    work = pd0 & 0xf0;
    /* ==== Set Port ==== */
    prc2 = 1; /* Protect off */
    pd0 = work;
    //P0_3/AN4...P0_0/AN7 port direction = input
    /* ---- Disable A/D conversion interrupt ---- */
    adic = 0x00;
    /* ---- Stop A/D conversion ---- */
    adcon0 = 0x00;
    //Cut off on-chip reference voltage and analog input
    prc3 = 1; /* Protect off */
    ocvrefan = 0;
    prc3 = 0; /* Protect on */
    /* ---- Set A/D mode ---- */
    admod = 0x22; //Division select : fAD divided by 2
    /* Clock source : f1 */
    /* A/D operating mode : single sweep mode */
    /* Start A/D conversion by software trigger */
    //When the CKS2 bit is changed, wait for 3 fAD cycles
    //or more before starting A/D conversion
    for (int i = 0; i < 10; i++)
    {
    }
    /* ---- Set A/D inputs ---- */
    adinsel = 0x30; /* Analog input pin : AN0 to AN7 */
    /* A/D sweep pin count : 8 pins */
    /* A/D input group : Port P0 */
    /* ---- Set A/D control register ---- */
    adcon1 = 0x30;
    /* Not select extended analog input pin */
    /* 10-bit mode */
    /* Enable A/D operation */
    /* A/D open-circuit detection
 /* assist function disabled */
    /* When the ADSTBY bit is changed */
    /* from 0 (A/D operation stops) to 1*/
    /* (A/D operation enabled),*/
    /* wait for 1 fAD cycle */
    for (int i = 0; i < 10; i++)
    {
    }
    adic = 0x05; /* level 5*/
}
