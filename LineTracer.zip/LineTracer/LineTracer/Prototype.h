void Hwsetup (void);
void InitMotor( int rate );
void MotorDrive( int dir, int left, int right);
void wheel(int lm, int rm);
void InitAdc(void);
void ad_read(void); /* Set A/D fixed value */ 
void Analog(void);
void InitTimer(void);
void OnTimer( int n );
void OffTimer( int n );
int ChkTimer( int n );
void InitUart0(void);
void InitInput(void);
void Input(void);
bool IsStartPB(void); 
void GetValues(int data[]);