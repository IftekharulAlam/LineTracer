#include "LineFollower.h"

struct inpCtr
{
    unsigned short on;
    unsigned short off;
};

static struct inpCtr inpTbl[INNUM];

const bool logic[INNUM] = {
    NEG, // 0 START_PB
};

static const unsigned short LIMIT = 50;

static const unsigned short MANY = 45;

static int step;

void InitInput()
{
    struct inpCtr *sp = inpTbl;
    for (int n = INNUM; n-- > 0;)
    {
        sp->on = 0;
        sp->off = 0;
        sp++;
    }
    step = 0;
}
void Input()
{
    int n;
    struct inpCtr *sp = inpTbl;
    for (int m = 0; m < INNUM; m++)
    {
        switch (m)
        {
        case START_PB:
            n = p2_0;
            break;
        default:
            n = 0;
        }
        if (n)
        {
            if (sp->on < LIMIT)
                sp->on++;
            if (sp->off > 0)
                sp->off--;
        }
        else
        {
            if (sp->off < LIMIT)
                sp->off++;
            if (sp->on > 0)
                sp->on--;
        }
        sp++;
    }
};
int ChkIn(int n)
{
    struct inpCtr *sp;
    const bool *sq;
    sp = &inpTbl[n];
    sq = &logic[n];
    if (sp->on > MANY)
        return (*sq == POS) ? ON : OFF;
    else if (sp->off > MANY)
        return (*sq == POS) ? OFF : ON;
    else
        return -1;
}
bool IsStartPB()
{
    bool flag = false;
    switch (step)
    {
    case 0:
        if (ChkIn(START_PB) == ON)
        {
            flag = true;
            step++;
        }
        break;
    case 1:
        if (ChkIn(START_PB) == OFF)
            step = 0;
        break;
    default:
        step = 0;
    }
    return flag;
};