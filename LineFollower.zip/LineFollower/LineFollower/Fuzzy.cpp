#include "LineFollower.h"
int Fuzzy(int newVal)
{
 return 0;
} 