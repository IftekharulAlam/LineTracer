#include "LineFollower.h"
#define PERIOD 40000
#define slowSpeed 50 //% tentative
#define normalSpeed 70 //% tentative
#define CONFIRM2 5 //tentative
#define CONFIRM3 30 //tentative
#define ZONE 5
#define BETA 50 //10->0
#define abs(n) ((n >= 0) ? n : -n )
static short counter ;
static short stage ; //Control Stage
enum { S_FORWARD, S_BACKWARD, S_BACKWARD2,
 S_RETURN, S_RETURN2 };
static int oldResult ; //Previous result
static int which ; 
static long maxValue;
void MotorStart()
{
 stage = S_FORWARD ;
 counter = 0 ;
 oldResult = 0 ;
 MotorDrive( FORWARD, slowSpeed, slowSpeed );
}
//
void MotorStop()
{
 MotorDrive( STOP, 0, 0 );
} 
void InitMotor(int rate)
{
    maxValue = ((long)PERIOD * rate) / 100;
    trdgra0 = trdgrc0 = PERIOD - 1;
    trdgrb0 = trdgrd0 = maxValue / 2; // PWM 1
    trdgra1 = trdgrc1 = maxValue / 2; // PWM 2
    trdstr = 0x05;                    // start TRD0 count
}
void MotorDrive(int dir, int left, int right)
{
    if (dir == STOP) //Stop
    {
        p2_1 = 0;
        p2_6 = 0;
        p2_3 = 0;
        p2_7 = 0;
    }
    else
    {
        trdgrd0 = (maxValue * left) / 100;  // PWM1
        trdgrc1 = (maxValue * right) / 100; // PWM2
        switch (dir)
        {
        case FORWARD:
            p2_1 = 0; // Left wheel
            p2_6 = 1;
            p2_3 = 0; // Right wheel
            p2_7 = 1;
            break;
        case BACKWARD:
            p2_1 = 1; // Left wheel
            p2_6 = 0;
            p2_3 = 1; // Right wheel
            p2_7 = 0;
            break;
        case TORIGHT:
            p2_1 = 0; // Left Forward
            p2_6 = 1;
            p2_3 = 1; // Right Backward
            p2_7 = 0;
            break;
        case TOLEFT:
            p2_1 = 1; // Left Backward
            p2_6 = 0;
            p2_3 = 0; // Right Forward
            p2_7 = 1;
            break;
        }
    }
}


void MotorControl()
{
 int diff = 0 ;
 int result = 0;
 int sensor[4];
 GetValues(sensor); // Get sensor values
 switch ( stage ){
 case S_FORWARD : //FORWARD
 //Both sensor is out of the path
 if ( sensor[1] < BRIGHT && sensor[2] < BRIGHT )
 {
 //For confirmation
 if (( counter += 1 ) >= CONFIRM2 )
 {
 MotorDrive( STOP, 0, 0 ); //Pause
 stage = S_BACKWARD ; //To backward
 }
 }
 else //On the path
 {
 counter = 0;
 diff = sensor[2] - sensor[1] ;
 result = Fuzzy( diff );
 if ( oldResult != result )
 {
 oldResult = result ; //Previous result
 //When the operaton instruction is small
 if ( abs(result) <= ZONE )
 {
 int base = normalSpeed ;
 MotorDrive( FORWARD, base+result,
 base-result ); //Normal speed
 }
 //When the operaton instruction is big
 else
 {
 int base = slowSpeed;
 MotorDrive( FORWARD, base+result,
 base-result ); //Slow down
 }
 }
 }
 break ; 
 case S_BACKWARD : //BACKWARD
 MotorDrive( BACKWARD, slowSpeed,
 slowSpeed );
 counter = 0 ;
 which = 0;
 stage++;
 break;
 case S_BACKWARD2 :
 //Either of the sensor is on the path
 if ( sensor[1] >= DARK || sensor[2] >= DARK )
 {
 //For confirmation,
 //until both sensor is on the path
 if ( sensor[1] >= DARK && sensor[2] >= DARK )
 {
 if (( counter += 1 ) > CONFIRM3 )
 {
 MotorDrive( STOP, 0, 0 ); //Pause
 stage = S_RETURN ; //Next stage
 break ;
 }
 }
 else
 {
 counter = 0;
 }
 //Left sensor is on the path
 if ( sensor[2] > sensor[1] + BETA )
 {
 int base = slowSpeed; //Slow down
 //Modify the direction
 MotorDrive( TOLEFT, base-20, base+20 );
 if ( which == 0 )
 which = TOLEFT;
 }
 //Right sensor is on the path
 else if ( sensor[2] < sensor[1] - BETA )
 {
 int base = slowSpeed; //Slow down
 //Modify the direction
 MotorDrive( TORIGHT, base+20, base-20 );
 if ( which == 0 )
 which = TORIGHT;
 }
 }
 else
 {
 counter = 0;
 }
 break ; 
 case S_RETURN : //Modify the direction
 //Modify the direction using the value of counter
 if ( which == TOLEFT )
 {
 int base = slowSpeed; //Slow down
 //Left fix, move only Right wheel
 MotorDrive( FORWARD, 0, base+20 );
 }
 else if ( which == TORIGHT)
 {
 int base = slowSpeed; //Slow down
 //Right fix, move only Left wheel
 MotorDrive( FORWARD, base+20,0 );
 }
 if (( counter -= 1) <= 0 )
 stage = S_RETURN2 ;
 break ;
 case S_RETURN2 : //Return to Forward
 counter = 0 ;
 oldResult = 0 ;
 stage = S_FORWARD ;
 break ;
 }
} 