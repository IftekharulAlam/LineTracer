-------- PROJECT GENERATOR --------
PROJECT NAME :	LineFollower
PROJECT DIRECTORY :	C:\WorkSpace\LineFollower\LineFollower
CPU SERIES :	R8C/Tiny
CPU GROUP :	34C
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	6.00.00
GENERATION FILES :
    C:\WorkSpace\LineFollower\LineFollower\LineFollower.cpp
        main program file.
    C:\WorkSpace\LineFollower\LineFollower\nc_define.inc
        interrupt program.
START UP FILES :
    C:\WorkSpace\LineFollower\LineFollower\ncrt0.a30
    C:\WorkSpace\LineFollower\LineFollower\sect30.inc
    C:\WorkSpace\LineFollower\LineFollower\sfr_r834c.inc
    C:\WorkSpace\LineFollower\LineFollower\sfr_r834c.h

DATE & TIME : 12/2/2021 7:29:25 PM
