#include "sfr_r834c.h"
#include "Prototype.h"
extern unsigned short ad_data[4]; //A/D conversion result
enum { STOP,FORWARD,BACKWARD,TORIGHT,TOLEFT }; 
enum {
 START_PB,
 INNUM
};
enum { OFF,ON,UP };
enum { NEG, POS }; 
enum {
 TM00, //SCI timer
 TM01, //
 TMRNUM
};
#define DARK 570 //03C4 => 964 700->570
#define BRIGHT 450 //0038 => 56 300->450 